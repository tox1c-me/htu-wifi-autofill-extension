document.addEventListener('DOMContentLoaded', function() {

  // ========== 选项卡切换 ==========
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const targetTab = this.dataset.tab;
      tabBtns.forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      tabContents.forEach(c => c.classList.remove('active'));
      document.getElementById('tab-' + targetTab).classList.add('active');
    });
  });

  // ========== 加载保存的配置 ==========
  loadConfig('jiaoxueConfig', {
    username: 'j-username',
    password: 'j-password',
    autoSubmit: 'j-autoSubmit',
    enabled: 'j-enabled'
  });

  loadConfig('susheConfig', {
    username: 's-username',
    password: 's-password',
    operator: 's-operator',
    autoSubmit: 's-autoSubmit',
    enabled: 's-enabled'
  });

  function loadConfig(storageKey, fieldIds) {
    chrome.storage.sync.get([storageKey], function(data) {
      const config = data[storageKey] || {};
      if (config.username) document.getElementById(fieldIds.username).value = config.username;
      if (config.password) document.getElementById(fieldIds.password).value = config.password;
      if (fieldIds.operator && config.operator) document.getElementById(fieldIds.operator).value = config.operator;
      document.getElementById(fieldIds.autoSubmit).checked = config.autoSubmit !== false;
      document.getElementById(fieldIds.enabled).checked = config.enabled !== false;
    });
  }

  // ========== 教学区保存 ==========
  document.getElementById('j-saveBtn').addEventListener('click', function() {
    saveAndShowStatus('jiaoxueConfig', {
      username: 'j-username',
      password: 'j-password',
      autoSubmit: 'j-autoSubmit',
      enabled: 'j-enabled'
    }, '教学区');
  });

  // ========== 宿舍区保存 ==========
  document.getElementById('s-saveBtn').addEventListener('click', function() {
    saveAndShowStatus('susheConfig', {
      username: 's-username',
      password: 's-password',
      operator: 's-operator',
      autoSubmit: 's-autoSubmit',
      enabled: 's-enabled'
    }, '宿舍区');
  });

  function saveAndShowStatus(storageKey, fieldIds, areaName) {
    const username = document.getElementById(fieldIds.username).value.trim();
    const password = document.getElementById(fieldIds.password).value.trim();

    if (!username || !password) {
      showStatus('⚠️ 请填写账号和密码', 'error');
      return;
    }

    const config = {
      username: username,
      password: password,
      autoSubmit: document.getElementById(fieldIds.autoSubmit).checked,
      enabled: document.getElementById(fieldIds.enabled).checked
    };

    if (fieldIds.operator) {
      config.operator = document.getElementById(fieldIds.operator).value;
    }

    chrome.storage.sync.set({ [storageKey]: config }, function() {
      showStatus(`✅ ${areaName}配置已保存`, 'success');
    });
  }

  // ========== 教学区立即填充 ==========
  document.getElementById('j-fillBtn').addEventListener('click', function() {
    fillCurrentTab('jiaoxueConfig');
  });

  // ========== 宿舍区立即填充 ==========
  document.getElementById('s-fillBtn').addEventListener('click', function() {
    fillCurrentTab('susheConfig');
  });

  function fillCurrentTab(storageKey) {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs[0]) {
        // 重新加载页面触发content.js
        chrome.tabs.reload(tabs[0].id);
        showStatus('🔄 正在刷新并填充...', 'success');
      }
    });
  }

  function showStatus(message, type) {
    const statusEl = document.getElementById('status');
    statusEl.textContent = message;
    statusEl.className = 'status ' + type;
    setTimeout(() => {
      statusEl.textContent = '';
      statusEl.className = 'status';
    }, 2000);
  }
});